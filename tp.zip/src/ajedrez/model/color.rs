/// Enumeración de los colores de las fichas de ajedez.
#[derive(PartialEq, Debug)]
pub enum Color {
    Blanco,
    Negro,
}
