pub mod casilla;
pub mod color;
pub mod info;
pub mod pieza;
pub mod resultado;
pub mod tablero;
